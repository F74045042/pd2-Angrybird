# AngryThings
Final project of 2016 Spring Class

# How to use
We have provided you :
* Basic Window (Basic control of game , world of box2D have been created.)
* Basic GameItem (For everything's parent)
* Basic event control (You can extend from here)

###### Warning : 
###### This version is compiling with Box2D's library on Linux , so if your OS is windows , you should replace the libBox2D.a with the one in "Library/Windows".

# About Directory 
* src : main program all in here. (Open Qt creator , and load .pro file for open)
  * Box2D : box2D's header file.
  * image : store the image we use.
* Library : provide with different library for OS.
  * Windows : Box2D library for Windows.

# UML Diagram
![alt text][figure_lab2]

[figure_lab2]:https://github.com/ncku-pd2/Example-code-for-Project-3/blob/master/UML%20diagram/UML_diagram.png

# Reference 
[box2D](http://box2d.org/)
